#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Enter the description of your new custom indicator here
    /// </summary>
    [Description("Enter the description of your new custom indicator here")]
    public class ADXBDinamica : Indicator
    {
        #region Variables
        // Wizard generated variables
            private int valorMaxADX = 300; // Default setting for HH
            private int periodo = 14; // Default setting for ADX
            private double tBanda = 0.5; // Default setting for Multiplo
        // User defined variables (add any user defined variables below)
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "MaxADX"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "ValorADX"));
            Add(new Plot(Color.FromKnownColor(KnownColor.DarkViolet), PlotStyle.Line, "BandaDinamica"));
            CalculateOnBarClose	= true;
            Overlay				= false;
            PriceTypeSupported	= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            if (CurrentBar < ValorMaxADX) return;
			
            MaxADX.Set(MAX(ADX(Periodo), ValorMaxADX)[0]);
            ValorADX.Set(ADX(Periodo)[0]);
            BandaDinamica.Set(MaxADX[0]* TBanda);
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries MaxADX
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries ValorADX
        {
            get { return Values[1]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries BandaDinamica
        {
            get { return Values[2]; }
        }

        [Description("")]
        [Category("Parameters")]
        public int ValorMaxADX
        {
            get { return valorMaxADX; }
            set { valorMaxADX = Math.Max(1, value); }
        }

        [Description("")]
        [Category("Parameters")]
        public int Periodo
        {
            get { return periodo; }
            set { periodo = Math.Max(1, value); }
        }

        [Description("")]
        [Category("Parameters")]
        public double TBanda
        {
            get { return tBanda; }
            set { tBanda = Math.Max(0, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private ADXBDinamica[] cacheADXBDinamica = null;

        private static ADXBDinamica checkADXBDinamica = new ADXBDinamica();

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public ADXBDinamica ADXBDinamica(int periodo, double tBanda, int valorMaxADX)
        {
            return ADXBDinamica(Input, periodo, tBanda, valorMaxADX);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public ADXBDinamica ADXBDinamica(Data.IDataSeries input, int periodo, double tBanda, int valorMaxADX)
        {
            if (cacheADXBDinamica != null)
                for (int idx = 0; idx < cacheADXBDinamica.Length; idx++)
                    if (cacheADXBDinamica[idx].Periodo == periodo && Math.Abs(cacheADXBDinamica[idx].TBanda - tBanda) <= double.Epsilon && cacheADXBDinamica[idx].ValorMaxADX == valorMaxADX && cacheADXBDinamica[idx].EqualsInput(input))
                        return cacheADXBDinamica[idx];

            lock (checkADXBDinamica)
            {
                checkADXBDinamica.Periodo = periodo;
                periodo = checkADXBDinamica.Periodo;
                checkADXBDinamica.TBanda = tBanda;
                tBanda = checkADXBDinamica.TBanda;
                checkADXBDinamica.ValorMaxADX = valorMaxADX;
                valorMaxADX = checkADXBDinamica.ValorMaxADX;

                if (cacheADXBDinamica != null)
                    for (int idx = 0; idx < cacheADXBDinamica.Length; idx++)
                        if (cacheADXBDinamica[idx].Periodo == periodo && Math.Abs(cacheADXBDinamica[idx].TBanda - tBanda) <= double.Epsilon && cacheADXBDinamica[idx].ValorMaxADX == valorMaxADX && cacheADXBDinamica[idx].EqualsInput(input))
                            return cacheADXBDinamica[idx];

                ADXBDinamica indicator = new ADXBDinamica();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.Periodo = periodo;
                indicator.TBanda = tBanda;
                indicator.ValorMaxADX = valorMaxADX;
                Indicators.Add(indicator);
                indicator.SetUp();

                ADXBDinamica[] tmp = new ADXBDinamica[cacheADXBDinamica == null ? 1 : cacheADXBDinamica.Length + 1];
                if (cacheADXBDinamica != null)
                    cacheADXBDinamica.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheADXBDinamica = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.ADXBDinamica ADXBDinamica(int periodo, double tBanda, int valorMaxADX)
        {
            return _indicator.ADXBDinamica(Input, periodo, tBanda, valorMaxADX);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public Indicator.ADXBDinamica ADXBDinamica(Data.IDataSeries input, int periodo, double tBanda, int valorMaxADX)
        {
            return _indicator.ADXBDinamica(input, periodo, tBanda, valorMaxADX);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.ADXBDinamica ADXBDinamica(int periodo, double tBanda, int valorMaxADX)
        {
            return _indicator.ADXBDinamica(Input, periodo, tBanda, valorMaxADX);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public Indicator.ADXBDinamica ADXBDinamica(Data.IDataSeries input, int periodo, double tBanda, int valorMaxADX)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.ADXBDinamica(input, periodo, tBanda, valorMaxADX);
        }
    }
}
#endregion
